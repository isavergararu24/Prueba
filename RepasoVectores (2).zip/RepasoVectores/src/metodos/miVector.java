/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package metodos;

import javax.swing.JOptionPane;

/**
 *
 * @author Ruben
 */
public class miVector {
    private double vec[];
    
    miVector(){
        int tam=Integer.parseInt(
        JOptionPane.showInputDialog(
        "Entre tamaño del vector: "));
        vec = new double[tam];
        JOptionPane.showMessageDialog(null, 
        "Se ha creado el vector con el tamaño: "+tam);
    }
    
    public void setLlenar(){
        int i;
        for( i=0; i<vec.length; i++ ){
            vec[i] = Double.parseDouble(
            JOptionPane.showInputDialog(
            "Entre el valor para la posición "+i+":"
            ));
        }
    }
    
    public void getMostrar(){
        int i;
        String info = "Los datos del vector son: \n <";
        for( i=0; i<vec.length; i++ ){
            if( i < (vec.length-1) ){
                info += ""+vec[i]+", ";
            }else{
                info += ""+vec[i]+"> ";
            }
        }
        JOptionPane.showMessageDialog(null, info);
    }
    
    public void setBurbuja(){
        int i, j;
        double temp;
        
        for( i=0; i<vec.length; i++ ){
            for( j=0; j<(vec.length - 1); j++ ){
                if( vec[j] >= vec[j+1] ){
                    temp = vec[j+1];
                    vec[j+1] = vec[j];
                    vec[j] = temp;
                }
            }
        }        
    }
    
    //El método se basa en buscar en cada iteracción el mínimo
    //elemento del “subvector” situado entre el índice i y el 
    //final del vector e intercambiarlo con el de índice i. 
    public void setSeleccion(){
        int i, j, imin;
        double temp;
        for (i=0; i<vec.length; i++){
            imin=i;
            for (j=i+1; j<vec.length; j++){
                if(vec[j]<vec[imin])
                    imin=j;
            }
            temp = vec[i];
            vec[i] = vec[imin];
            vec[imin] = temp;
        }
    }
    
    //Se recurre a una búsqueda binaria en lugar de una 
    //búsqueda secuencial para insertar un elemento en la 
    //parte de arriba del arreglo, que ya se encuentra 
    //ordenado.
    public void setInsercion(){
        int i, j, Izq, Der, Medio;
        double temp;
        for(i=1; i<vec.length; i++) {
            temp = vec[i];
            Izq = 0;
            Der = i-1;
            while(Izq <= Der){
                Medio = (Izq+Der)/2;
                if (temp < vec[Medio])
                    Der = Medio - 1;
                else
                    Izq = Medio + 1;
            }
            for (j=i-1; j>=Izq; j--){
                vec[j+1]=vec[j];
            }
            vec[Izq] = temp;
        }
    }
    
    //Denominado así por su desarrollador Donald Shell (1959),
    //ordena utilizando la segmentación (salto), puede ser de 
    //cualquier tamaño de acuerdo a una secuencia de 
    //valores que empiezan con un valor grande 
    //(pero menor al tamaño total de la estructura) 
    //y van disminuyendo hasta llegar al '1'.
    public void setShell(){
        int salto, i;
        double temp;
        boolean cambios;
  
        for (salto = vec.length / 2; salto != 0; salto /= 2) {
            cambios = true;
            while (cambios) {   // Mientras se intercambie algún elemento                                         
                cambios = false;
                for (i = salto; i < vec.length; i++)   // se da una pasada
                {
                    if (vec[i - salto] > vec[i]) {       // y si están desordenados
                        temp = vec[i];                  // se reordenan
                        vec[i] = vec[i - salto];
                        vec[i - salto] = temp;
                        cambios = true;              // y se marca como cambio.                                   
                    }
                }
            }
        }
    }
    
    public void setQuickSort(int ind_izq, int ind_der){
        int i, j; /* variables indice del vector */
        double elem; /* contiene un elemento del vector */
        i = ind_izq;
        j = ind_der;
        elem = vec[(ind_izq+ind_der)/2];
        
        do{
            while (vec[i] < elem) //recorrido del vector hacia la derecha
                i++;
            while (elem < vec[j]) // recorrido del vector hacia la izquierda
                j--;
            if (i <= j){ /* intercambiar */
                double aux; /* variable auxiliar */
                aux = vec[i];
                vec[i] = vec[j];
                vec[j] = aux;
                i++;
                j--;
            }
        } while (i <= j);
        if (ind_izq < j) {setQuickSort(ind_izq, j);} //Llamadas recursivas
        if (i < ind_der) {setQuickSort(i, ind_der);}
    }

    public int getTamVec(){ return vec.length; }
}
