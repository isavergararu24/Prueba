/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package metodos;

import javax.swing.JOptionPane;

/**
 *
 * @author Ruben
 */
public class miProbador {
    public static void main(String args[]){
        miVector data=null;
        int op;
        
        do{
            op = Integer.parseInt(JOptionPane.showInputDialog(
            "Menú principal \n"+
            "1. Crear vector \n"+
            "2. Llenar vector \n"+
            "3. Mostrar vector \n"+
            "4. Ordenar vector \n"+
            "5. Salir \n"+
            "Entre su opción: ?"
            ));
            
            switch(op){
                case 1:
                    data = new miVector();
                break;
                case 2:
                    data.setLlenar();
                break;
                case 3:
                    data.getMostrar();
                break;
                case 4:
                    //data.setBurbuja();
                    //data.setSeleccion();
                    data.setInsercion();
                    //data.setShell();
                    //data.setQuickSort(0, (data.getTamVec() - 1));
                    data.getMostrar();
                break;
                case 5:
                    JOptionPane.showMessageDialog(null, 
                    "Adios!!");
                break;
                default:
                    JOptionPane.showMessageDialog(null, 
                    "Error: Opción invalida!!");
            }
                        
        }while(op!=5);
        
        System.exit(0);
    }
}
